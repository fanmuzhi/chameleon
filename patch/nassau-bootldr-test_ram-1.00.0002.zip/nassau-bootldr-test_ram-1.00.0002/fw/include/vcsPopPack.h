/* -*- mode: c; tab-width: 4 -*- */
/*
 * Copyright (c) 2007-2015 Synaptics Incorporated.  All rights reserved.
 */

/*
 * vcsPopPack.h for the Falcon firmwware.
 *
 * This is simply a dummy header to allow the firmware to include
 *   .../falcon/shared/vcsfw_v4.h without messing up.
 *
 * Bjoren Davis, September 26, 2007.
 *  Adapted for Savoy from engineering/private/impl/micro/windsor/fwrom/src/vcsPopPack.h,v 1.2 2013/02/08 21:43:17 bdavis
 *   by Bjoren Davis on February 20, 2015.
 */


